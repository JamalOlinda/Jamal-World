const numStr = "geoff"
if (isNaN(parseFloat(numStr))){
    console.log("É NaN!")
} else {
    console.log("Não é NaN")
}