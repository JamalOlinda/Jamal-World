let num = Number(123.45)
console.log(num)