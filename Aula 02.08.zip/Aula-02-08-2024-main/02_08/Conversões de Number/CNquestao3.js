let numeroarredondado = 3.14463
let string = numeroarrendondado.toFixed(3)
console.log(stringFormatada)