let num = 4.7
let arredondado = Math.round(num)
console.log(num)