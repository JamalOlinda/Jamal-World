let vazio = null

console.log(vazio == undefined)
console.log(vazio === undefined)