let naoDefinida

console.log(naoDefinida == undefined)
console.log(naoDefinida === undefined)