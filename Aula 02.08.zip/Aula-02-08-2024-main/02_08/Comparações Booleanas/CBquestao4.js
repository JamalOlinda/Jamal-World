let a = 5, b = 10

console.log(a != b)
console.log(a !== b)