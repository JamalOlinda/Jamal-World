let frase = "Jogar bola é incrível.", palavra1 = "incrível", palavra2 = "fantástico", novafrase = frase.replace("incrível", "fantástico")

console.log(novafrase)