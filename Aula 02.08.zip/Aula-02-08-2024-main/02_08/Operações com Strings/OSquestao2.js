let frase = "Tudo bem", comprimento = frase.length
console.log("A frase possui",comprimento, "caracteres.")