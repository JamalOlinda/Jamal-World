let frase = "JavaScript é incrível!"
console.log(frase)