let frase = "A vida é incrível.";
let palavra = "incrível";

if (frase.includes(palavra)) {
    console.log(palavra);
}