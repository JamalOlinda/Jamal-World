function multiplica(a, b) {
    return a * b;
  }
  
  
  const resultadoMultiplicacao = multiplica(7, 8);
  console.log("Resultado da multiplicação:", resultadoMultiplicacao);
  