const chave1 = Symbol("descrição da chave");

const chave2 = Symbol("descrição da chave");

console.log("chave1 é igual a chave2?", chave1 === chave2);